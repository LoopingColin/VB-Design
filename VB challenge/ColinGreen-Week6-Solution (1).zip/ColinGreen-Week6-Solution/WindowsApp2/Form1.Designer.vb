﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GeneralList = New System.Windows.Forms.Label()
        Me.ListBoxStudents = New System.Windows.Forms.ListBox()
        Me.ListBoxClubMembers = New System.Windows.Forms.ListBox()
        Me.MemberList = New System.Windows.Forms.Label()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.btnRemoveStudent = New System.Windows.Forms.Button()
        Me.MemberCount = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'GeneralList
        '
        Me.GeneralList.AutoSize = True
        Me.GeneralList.Location = New System.Drawing.Point(101, 56)
        Me.GeneralList.Name = "GeneralList"
        Me.GeneralList.Size = New System.Drawing.Size(103, 13)
        Me.GeneralList.TabIndex = 0
        Me.GeneralList.Text = "General Student List"
        '
        'ListBoxStudents
        '
        Me.ListBoxStudents.FormattingEnabled = True
        Me.ListBoxStudents.Items.AddRange(New Object() {"Adams, Ben", "Baker, Sally", "Canseco, Juan", "Davis, Sharon", "Etienne, Jean", "Gonzalez, Jose", "Koenig, Johann", "Nakamura, Ken", "Ramirez, Maria"})
        Me.ListBoxStudents.Location = New System.Drawing.Point(73, 82)
        Me.ListBoxStudents.Name = "ListBoxStudents"
        Me.ListBoxStudents.Size = New System.Drawing.Size(167, 225)
        Me.ListBoxStudents.TabIndex = 1
        '
        'ListBoxClubMembers
        '
        Me.ListBoxClubMembers.FormattingEnabled = True
        Me.ListBoxClubMembers.Items.AddRange(New Object() {"Baker, Sally", "Gonzalez, Jose", "Matsunaga, Akiko", "Nakamura, Ken"})
        Me.ListBoxClubMembers.Location = New System.Drawing.Point(410, 82)
        Me.ListBoxClubMembers.Name = "ListBoxClubMembers"
        Me.ListBoxClubMembers.Size = New System.Drawing.Size(167, 225)
        Me.ListBoxClubMembers.TabIndex = 2
        '
        'MemberList
        '
        Me.MemberList.AutoSize = True
        Me.MemberList.Location = New System.Drawing.Point(445, 56)
        Me.MemberList.Name = "MemberList"
        Me.MemberList.Size = New System.Drawing.Size(107, 13)
        Me.MemberList.TabIndex = 3
        Me.MemberList.Text = "Club Membership List"
        '
        'btnAddStudent
        '
        Me.btnAddStudent.Location = New System.Drawing.Point(261, 164)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(105, 96)
        Me.btnAddStudent.TabIndex = 4
        Me.btnAddStudent.Text = "Add Student"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'btnRemoveStudent
        '
        Me.btnRemoveStudent.Location = New System.Drawing.Point(599, 164)
        Me.btnRemoveStudent.Name = "btnRemoveStudent"
        Me.btnRemoveStudent.Size = New System.Drawing.Size(105, 96)
        Me.btnRemoveStudent.TabIndex = 5
        Me.btnRemoveStudent.Text = "Remove Student"
        Me.btnRemoveStudent.UseVisualStyleBackColor = True
        '
        'MemberCount
        '
        Me.MemberCount.AutoSize = True
        Me.MemberCount.Location = New System.Drawing.Point(611, 293)
        Me.MemberCount.Name = "MemberCount"
        Me.MemberCount.Size = New System.Drawing.Size(76, 13)
        Me.MemberCount.TabIndex = 6
        Me.MemberCount.Text = "Member Count"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MemberCount)
        Me.Controls.Add(Me.btnRemoveStudent)
        Me.Controls.Add(Me.btnAddStudent)
        Me.Controls.Add(Me.MemberList)
        Me.Controls.Add(Me.ListBoxClubMembers)
        Me.Controls.Add(Me.ListBoxStudents)
        Me.Controls.Add(Me.GeneralList)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GeneralList As Label
    Friend WithEvents ListBoxStudents As ListBox
    Friend WithEvents ListBoxClubMembers As ListBox
    Friend WithEvents MemberList As Label
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents btnRemoveStudent As Button
    Friend WithEvents MemberCount As Label
End Class
