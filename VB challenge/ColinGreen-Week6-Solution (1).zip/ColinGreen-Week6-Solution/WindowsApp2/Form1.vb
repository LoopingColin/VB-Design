﻿Public Class Form1
    ' Lists to store club members
    Dim clubMembers As New List(Of String)

    Private Sub btnAddStudent_Click(sender As Object, e As EventArgs) Handles btnAddStudent.Click
        ' Add a student to the club 
        If ListBoxStudents.SelectedIndex >= 0 Then
            Dim selectedStudent As String = ListBoxStudents.SelectedItem.ToString()
            If Not clubMembers.Contains(selectedStudent) Then
                clubMembers.Add(selectedStudent)
                ListBoxClubMembers.DataSource = Nothing ' 
                ListBoxClubMembers.DataSource = clubMembers
                MemberCount.Text = "Club Members: " & clubMembers.Count.ToString()
            End If
        End If
    End Sub

    Private Sub btnRemoveStudent_Click(sender As Object, e As EventArgs) Handles btnRemoveStudent.Click
        ' Remove a student from the club 
        If ListBoxClubMembers.SelectedIndex >= 0 Then
            Dim selectedMember As String = ListBoxClubMembers.SelectedItem.ToString()
            clubMembers.Remove(selectedMember)
            ListBoxClubMembers.DataSource = Nothing ' 
            ListBoxClubMembers.DataSource = clubMembers
            MemberCount.Text = "Club Members: " & clubMembers.Count.ToString()
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ListBoxClubMembers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxClubMembers.SelectedIndexChanged

    End Sub
End Class
